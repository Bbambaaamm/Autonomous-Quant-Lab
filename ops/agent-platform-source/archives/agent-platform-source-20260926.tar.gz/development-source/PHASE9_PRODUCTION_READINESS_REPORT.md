# Phase9 production readiness report

PHASE9_READY_FOR_ADMIN_ACTIVATION

Q1/Q2/Q3 approved. Implementation and admin handoff prepared; **ACTIVATION_BLOCKED**
for agentops: privileged actions belong exclusively to quantadmin. Nothing activated.
Local commit is NOT created: explicit user commit approval remains required.
Baseline `9cf68b0ff1ad7bab50acfdff0f2e359e57ece308`, branch
`codex/agent-platform-phase1`, initially clean; coordinator is sole repository writer.

## Delivered behavior and decisions

Separate production modules preserve the Phase7 fixture API and Phase8 historical
refusal templates. New production Nginx fragment gates the entire exact/prefix path
with Basic Auth for michal and forwards credentials only to loopback3010. Backend
independently verifies PBKDF2-SHA256, preventing local/header spoof bypass. Credentials
are generated ONLY by quantadmin in a private TTY at activation: no real password
was generated here. Root-owned salted hash/verifier files, no plaintext persistence,
no argv/env/log password; once-only TTY display and repeat-generation refusal.

Web reads only the bounded, closed, atomically published sanitized snapshot. No
SQLite, subprocess, Herdr/control, model/provider/router helpers or fixture import
in the HTTP path. Startup preflight requires fresh available router and nonempty
Herdr coverage for every explicitly granted profile. Runtime source failures are
unavailable; stale/future/replayed whole snapshot fails503. No allow/deny controller,
fallback or dispatch integration. Existing automatic fallback/free-only behavior is
unchanged because no existing runtime/router source was modified.

One-shot exporter: root-owned explicit profile registry, fixed SQL/command/query
allowlists, bounded file/row/output/time limits, no-follow regular-file validation,
query_only verified, trusted_schema off, SQL authorizer, no immutable=1 for live
WAL. Single-instance flock, atomic rename, file+directory fsync, mode0640 output.
Subprocesses have minimal explicit env and are killed/reaped on overflow/timeout/
BaseException. Export service additionally denies network-io syscalls. No API retry.
Separate Herdr status bridge executes ONLY `agent list`, checks explicit name+
pane/profile binding and publishes explicit coverage. The socket is control-capable;
bridge code/process isolation is not a server-enforced read-only capability. Web
and regular exporter do not receive it. Source owners and root registry remain
trusted boundaries; metadata allowlisting is not anonymization.

Snapshot carries profile, kind, observation/data timestamps, source status/reason,
optional immutable Kanban board/epoch, bounded rows. Task IDs are stable profile-
scoped SHA256 pseudonyms for cross-source correlation; this is not proof that a
router task belongs to a specific Kanban board. No prompts/args/output/memory,
error_message, credentials, send_token, diff content or remote URI in snapshots.
Unknown cost is null; measured zero and unavailable are distinct. Router totals
cover the last1000 requests, at most50 task groups, not all-time accounting.

## Source evidence and production limitations

Coordinator inspected code and actual schema for BOTH router DBs, metadata only:
`/home/agentops/.hermes/profiles/majak/model-router/router.db` and corresponding
quantlab path. URI mode=ro, query_only=1 verified. Actual requests fields include
id/task_id/started_at/ended_at/input_tokens/output_tokens/cost_usd. Sensitive columns
were seen in schema but never selected as data. Initial sandbox schema open failed;
authorized metadata-only inspection outside sandbox succeeded. No request rows
were read and no second live data-row inspection was performed.

Kanban schema independently checked in hermes_cli/kanban_db.py (tasks id/status/
current_run_id/created_at). No actual live Kanban store found in inspected default
and profile board roots. Config deliberately keeps kanban:null/unavailable; no
invented path/identity. The adapter is covered against temp SQLite only. Admin must
verify real path, schema, board/epoch and ACL before a non-null source is admitted.

Herdr `agent list` was verified read-only under the exact minimal subprocess env;
1933 response bytes, no raw response logged or snapshot published. Actual production
socket mount, copied root-owned binary and binding registry still require admin
confirmation. Git repositories and structured report sources likewise require
explicit mounts/allowlists; examples leave them null. Git tested on a real temporary
repo (HEAD/dirty only). Structured report reader rejects wrong profile, raw fields
and >24h age. No automatic Markdown/log parser or report producer is installed.

Live WAL access through read-only systemd mounts must be verified by admin; missing
regular sidecars/access => unavailable, not recovery or permissions modification.
No production TLS/auth routing, effective sandbox enforcement, port collision scan,
service startup or rollback execution is claimed by these offline checks. Shared
HTTPS origin still trusts the existing QuantLab origin. Public route activation
requires BOTH profiles' router+Herdr availability; optional null sources require an
explicit recorded acknowledgement of incomplete source coverage.

## Independent review and corrections

At most two delegations per agent, no duplicate prompt/timeout retry:

- Majak-hermes PHASE9_ARCH_READY identified control-capable Herdr socket, explicit
  scope bindings, fixture-only mismatch, backend bypass defense and collision/rollback
  gates. Incorporated and independently checked in local code.
- Quantlab-hermes initial PHASE9_PRIVACY_READY incorrectly asserted absent Kanban
  schema definitions. Coordinator rejected that assertion and verified the actual
  source; did not treat its initial zero verdict as sufficient evidence.
- Quantlab-codex initial schema audit hit a duplicate approval prompt; user explicitly
  authorized cancellation. Final code/test review PHASE9_CODE_REVIEW_READY found
  P0 0, one P1: buffered r+ cannot open non-seekable TTY. Fixed with separate read/
  write streams plus O_NOCTTY/O_CLOEXEC. Added real PTY and fully mocked successful
  credential setup, once-only display/no plaintext persistence/repeat refusal tests.
- Majak-hermes final PHASE9_PRIVACY_REVIEW_READY found P0 0, one P1: unbound Herdr
  profile represented as available-zero. Fixed explicit coverage schema/validation;
  missing profile now unavailable/not_configured. Added partial/forged coverage tests.
- Quantlab-hermes second final correction review returned PHASE9_PRIVACY_READY,
  explicit P0 0/P1 0, confirming both fixes from actual files. Coordinator independently
  checked them and ran tests. Some historical Phase8 guard references in its response
  apply ONLY to Phase8 and are not claimed as production startup behavior here.

No unresolved P0/P1. Reviewers did not run tests. Coordinator additionally enforced
privacy review's required-source launch gate in web preflight, tested it, tightened
socket/binary checks and syscall isolation, and clarified idempotent admin commands.
No third delegation was made; these coordinator hardening checks are distinguished
from the reviewers' own execution evidence.

## Verification (actual results, no file retry)

Final canonical regression: **765 PASS, 0 FAIL, 31 files, 41.7s**. Includes the full
prior 30-file Phase8 regression (725 cases) plus **40 Phase9 cases (4.1s)**.
Commands use existing isolated devdeps overlay, PYTHONDONTWRITEBYTECODE=1,
`scripts/run_tests.sh ... -j 2 --file-retries 0`. No installation or live venv edit.

Covered: every HTTP route auth, local/forwarded identity denial, no collectors in
HTTP, explicit profile/copy_context isolation, stale/future/replay and malformed
snapshot, duplicate/sensitive JSON keys, no-follow paths/FIFO/permissions/limits,
lock exclusion and BaseException atomic publication, SQL write/sensitive-field
rejection, unknown cost, empty-vs-unavailable, row/window limits, actual temp Kanban
projection, report identity/age, Herdr explicit binding/coverage, bounded command
output/timeout/env, actual temp Git HEAD/dirty, real nonseekable PTY, mocked admin
credential success/no-secret-output/idempotent refusal, CLI default refusal and
mandatory-source startup gate. All DB/repo mutations in tests are temp-only.

Test history: expected missing-module red test (0 collected); initial sandbox runner
failed temp-directory access, then authorized canonical runner exposed expected
ModuleNotFoundError. Initial25 PASS, expanded33 PASS; pre-fix broader758 PASS. The
new PTY regression exposed SIGHUP from acquiring a controlling terminal; fixed with
O_NOCTTY, then36 PASS. This crash was not hidden by retry. Broader764 PASS preceded
the final additional startup gate test; final765 PASS above supersedes it.

Ruff all new Python files PASS. Profile-scope scanner:0 findings. Static AST safety
check: no embedded live source paths or Hermes/router/model/controller imports;
web has no source/export/Herdr/fixture/sqlite/subprocess dependency. Runtime tests
forbid network/SQLite/subprocess in requests. Diff checks green; cached diff and
exact staging manifest checked before requesting commit approval.

Native scratch checks: systemd-analyze verify exit0 for all units/timers, repeated
for final syscall restriction; only unrelated installed XFS CPUAccounting warnings.
Nginx1.28.3 -t exit0 against synthetic scratch HTTP server, scratch Unix socket/PID/
log/temp paths, no live config/certificates, no TCP listener or request worker. An
empty scratch PID may be created by -t. No systemctl/sudo/nginx reload executed.
WSGI HTML/API smoke is covered in tests; no screenshot/live listener needed.

## Activation and rollback commands

The complete precise quantadmin sequence, explicit path/commit confirmations,
idempotent skip-or-stop-on-drift rules, credential display, source binding, verify,
start/enable, paced curl401/200 and unchanged QuantLab200 checks are in
[production RUNBOOK](deploy/agent_platform/production/RUNBOOK.md).

Activation order: confirm shared HTTPS vhost/root3000/port3010 collision inventory;
install reviewed root-owned release; provision separate groups/user/output dirs;
configure and verify explicit source mounts/registry; generate password once from
private admin TTY; install/verify units; start Herdr bridge then exporter; mandatory
source/auth preflight; start web and test loopback401/200; enable bounded timers;
add exactly ONE include to confirmed existing HTTPS server (never replace vhost);
nginx -t, explicit reload, paced public401/200 and QuantLab200 smoke.

Rollback: FIRST restore full Phase8 deny503 exact/prefix/named-error fragment in
OUR include (avoid inherited error fallback), nginx -t and separately authorized
reload; verify deny + QuantLab200; only then stop/disable our web/timers/oneshots.
Do not delete databases, replace shared vhost, remove route reservation or redirect
to3000. Credentials remain private; rotation/revocation requires explicit admin
operation. Pre-activation failure changes only scratch/prepared artifacts.

## Production sample integrity

Three sampled live files match the prior baseline (not a full live filesystem audit):

- model-router __init__.py: 62e6a5b0ed2e25c45d5b17dc6a7df852384d62dd361cded51ea6219a1eedf9f1
- agent/conversation_loop.py: e5ebc04d14026ba493e5b238e615ddc775807344a04eab40c907750522052b91
- agent/turn_finalizer.py: 77ca6c9e92cb7e887fd1d0d950da417e5540a865a6866af9ad0c23b784e7f6bf

No live profiles/router source/services/Nginx/systemd edited. No password generation,
listener, deployment, push, package installation or explicit paid model API call.
All existing tracked repository files remain unchanged; only Phase9 additions.

## Exact Phase9 manifest (24 files)

- PHASE9_DESIGN.md
- PHASE9_PRODUCTION_READINESS_REPORT.md
- agent_platform_dashboard/production_auth.py
- agent_platform_dashboard/production_contract.py
- agent_platform_dashboard/production_credentials.py
- agent_platform_dashboard/production_export.py
- agent_platform_dashboard/production_herdr.py
- agent_platform_dashboard/production_io.py
- agent_platform_dashboard/production_sources.py
- agent_platform_dashboard/production_web.py
- deploy/agent_platform/production/RUNBOOK.md
- deploy/agent_platform/production/agent-platform-export.service.in
- deploy/agent_platform/production/agent-platform-export.timer.in
- deploy/agent_platform/production/agent-platform-herdr.service.in
- deploy/agent_platform/production/agent-platform-herdr.timer.in
- deploy/agent_platform/production/agent-platform-web.service.in
- deploy/agent_platform/production/herdr.example.json
- deploy/agent_platform/production/launch.py
- deploy/agent_platform/production/nginx-http.conf.in
- deploy/agent_platform/production/nginx-location-common.conf.in
- deploy/agent_platform/production/nginx-server.conf.in
- deploy/agent_platform/production/sources.example.json
- deploy/agent_platform/production/web.example.json
- tests/agent_platform_dashboard/test_production.py

External copy: /home/agentops/workspaces/majak/PHASE9_PRODUCTION_READINESS_REPORT.md
(outside repo, not staged). Requested local commit message:
`feat(deploy): add authenticated read-only agent platform runtime`.
Commit remains pending explicit user approval. Production activation remains a
separate quantadmin step; this marker certifies reviewed preparation, not deployment.

PHASE9_READY_FOR_ADMIN_ACTIVATION
